to get the cropped image
run the command:

auto_crop(img)

to get the trained classifier, run:

run()

note that the data should be put in ../data/
