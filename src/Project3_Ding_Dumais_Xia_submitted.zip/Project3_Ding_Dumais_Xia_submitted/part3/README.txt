Files contained in this folder are:

1. CNN.py 	This is the file to train the covolutional neural network
2. predictCNN.py 	This is file to predict results
3. prediction.csv	The prediction file submitted on Kaggle
4. autoencoder.py 	This file implements a set of autoencoder for training and predicting. 

In order to use the code, run "python CNN.py" first and then run "python predictCNN.py" 