This is the implementation of part 3, it contains the following file

1. Neuron.py 	The python class implementing the neuron
2. Layer.py 	The python class implementing the layer
3. Network.py 	The python class impementing the network layer
4. Feedfoward_Neural_Network. 	Connecting everything together to form the network
5. Noise_reducer The file does the data pre-processing 

In order to test the code, simply run the "python Feedforward_Neural_Network"